package model.report;

public class RepotDTO {

}
